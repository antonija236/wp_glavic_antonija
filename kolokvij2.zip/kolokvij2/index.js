var ime1 = prompt("unesi svoje ime: ");
alert("Vase ime je");